var firebaseConfig = {
    apiKey: "AIzaSyCswWpD6CuZETBbJCg6oIXHcGQiw58Rg38",
    authDomain: "fir-19513.firebaseapp.com",
    databaseURL: "https://fir-19513.firebaseio.com",
    projectId: "fir-19513",
    storageBucket: "fir-19513.appspot.com",
    messagingSenderId: "953394618053",
    appId: "1:953394618053:web:aebb764c72c01399f0daac"
};

firebase.initializeApp(firebaseConfig);
const ref = firebase.database().ref();

  //送信処理1
/************************
送信者設定
 ***********************/

//1. 配列を作成
const user=["オーナー","管理人","ユーザー"];

//2. 変数の入れ物を作成
let who="";

let fuck=user.length;//戸数自動取得用に変数作成
console.log(fuck);//コンソールで回数を確認
//3. 繰り返し処理で、文字列と配列を組み合わせ
for(let i=0; i<fuck/*回数を自動取得*/; i++){
  who+=`<option>${user[i]}からの連絡</option>`;
  //if(user==[1]){who='<img src="imgs/tuku.jpg" alt="">';}
}
//3.表示先
$("#uname").html(who);


/************************
イベント クリック
***********************/
//クリック
$("#send").on("click",function(){
    const uname = $("#uname").val();//送信者情報取得
    const text = $("#text").val();//メッセージ内容取得
    

    
//メッセージが無い場合は送信不可
if($("#text").val()==''){
  alert('メッセージを入力してください');
            $('#text').focus();
            return false;
}
    //時間の取得
    const d = new Date();  
    var Hour = d.getHours();
    var Min = d.getMinutes();

    //時間の表示について
    const bb = Hour + ":" + Min;

    //画像の取得
    //const file = $("#inputfile").val();
    // var reader= new FileReader(inputfile);
    // reader.readAsDataURL(file[0])
    // alert(reader);
    //送信一式
    const msg  = {
        uname/*変数*/: uname,
        text/*変数*/: text,
        time: bb,
        file: file,
    };
    ref.push(msg);//送信する
    //alert(msg);
    //スクロール アップ
    var $scrollAuto=$('.receive_left');
    $scrollAuto.animate({
    scrollTop: $scrollAuto[0].scrollHeight
    },0);
});


/************************
イベント enterで飛ばす
***********************/

$("#text").on("keydown",function(e){
    if(e.keyCode==13){
    const uname = $("#uname").val();
    const text = $("#text").val();
    //時間の取得
    const d = new Date();
    var Hour = d.getHours();
    var Min = d.getMinutes();
    
    //時間の表示について
    const bb =Hour + ":" + Min;
    
    //送信一式
    const msg  = {
        uname/*変数*/: uname,
        text/*変数*/: text,
        time: bb
    };
    ref.push(msg);//送信する
    //スクロール アップ
    var $scrollAuto=$('.receive_left');
    $scrollAuto.animate({
    scrollTop: $scrollAuto[0].scrollHeight
    },0);
    }
});



/************************
受信
***********************/

ref.on("child_added",function(date/*変数*/){
    const v = date.val();//オブジェクト変数がVに代入
    const k = date.key;//データのユニークKEY
    const u = '<p>'+v.uname+'</p>';//ユーザー名代入
    const h = '<p>'+v.text+'</p>';//メッセージ代入
    const t = '<p>'+v.time+'</p>';//時間代入
    //const f = '<p>'+v.reader+'</p>';

    const ccc ='<div id="icon" class="icon">'+u+'</div>'
    +'<br>'
    +'<div id="output" class="output">'+h+'</div>'
    +'<div id="time" class="time">'+t+'</div>'
    // +'<img src="'+f+'">';
    console.log(ccc);
    /*変数cccへ一括送信*/
    $("#receive_box").append(ccc).show(2000);//
    // $("#output").append(h);
    // $("#time").append(t);
    
    var chatDom =[];
    var p = function(dom){
    chatDom.push(dom);
  };
  
  // p('<div id="icon" class="icon"></div>');//アイコン取得
  // p('<div id="output" class="output"></div>');//メッセージ取得
  // p('<div id="time" class="time"></div>');//時間取得
  // //
  // $('#receive_box').append(chatDom.join(''));
});

/************************
clear クリックイベント
***********************/
    $("#delete").on("click",function(){
      localStorage.clear();
      $("#receive_box").empty();
  });
  





